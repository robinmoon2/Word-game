global using NUnit.Framework;
global using Projet_A2_S1;